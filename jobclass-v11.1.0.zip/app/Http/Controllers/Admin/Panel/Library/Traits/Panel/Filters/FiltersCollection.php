<?php

namespace App\Http\Controllers\Admin\Panel\Library\Traits\Panel\Filters;

class FiltersCollection extends \Illuminate\Support\Collection
{
	public function removeFilter($name)
	{
	}
	
	/*
	public function count()
	{
		dd($this);
	}
	*/
}
